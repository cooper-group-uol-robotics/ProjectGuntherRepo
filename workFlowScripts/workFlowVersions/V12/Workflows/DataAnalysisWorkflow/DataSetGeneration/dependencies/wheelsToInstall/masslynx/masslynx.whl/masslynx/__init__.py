import os
import importlib
import sys
from pathlib import Path

_is_64bits = sys.maxsize > 2**32
if _is_64bits:
    _dll_path = os.path.join(os.path.dirname(__file__), "dlls", "x64")
else:
    _dll_path = os.path.join(os.path.dirname(__file__), "dlls", "Win32")
os.add_dll_directory(_dll_path)

__all__ = []

for module in Path(__file__).parent.glob("*.py"):
    if module.stem != "__init__":
        m = importlib.import_module(f"masslynx.{module.stem}")
        names = [x for x in m.__dict__ if x.startswith("MassLynx")]
        globals().update({k: getattr(m, k) for k in names})
        __all__.extend(names)

