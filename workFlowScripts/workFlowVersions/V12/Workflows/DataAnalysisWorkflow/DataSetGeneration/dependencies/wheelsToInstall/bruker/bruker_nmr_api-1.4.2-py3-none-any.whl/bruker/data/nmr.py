#
# Implementation of data object for the Python 3 API
#


import array
import os

import grpc
import numpy
from remote_api.dataset_pb2 import IndexRangeDto, IndexRangesDto, IntegrationRegionsDto, IntegrationRegionDto
from bruker.model.nmr_model import NMRDataInfo, NMRData, ApiException

# Data set component names
RAWDATA = "RAWDATA"

# 1r,2rr, 3rrr...
PROCDATA = "PROCDATA"

# 1i,2ii...
PROCDATA_IMAG = "PROCDATA_IMAG"

# 2ir file
PROCDATA_MIX_IR = "PROCDATA_MIX_IR"
# 2ri file
PROCDATA_MIX_RI = "PROCDATA_MIX_RI"


# Element names of dictionary used to return data points
DATA_POINTS = 'dataPoints'
DATA_MATRIX = 'dataMatrix'
INDEX_RANGES = 'indexRanges'
PHYSICAL_RANGES = 'physicalRanges'
EXCEPTION = 'exc'
###############################################

class IndexRange(dict):
    '''
    IndexRange holds the information about selected range of indexes, typically used to specify a part of spectra
    '''
    def __init__(self, firstPoint:int, n:int):
        # initializing instance variable
        super().__init__()
        self['firstPoint'] = int(firstPoint)
        self['numberOfPoints'] = int(n)

    def getStart(self) -> int:
        return self['firstPoint']

    def getNum(self) -> int:
        return self['numberOfPoints']

    def fromIndexRangeDTO(dto):
        return IndexRange(dto.firstPoint, dto.numberOfPoints)

    def toIndexRangeDTO(self):
        return IndexRangeDto(firstPoint=self['firstPoint'], numberOfPoints=self['numberOfPoints'])

#####################################################
#
#  Physical Range stored as a python dictionary
#
class PhysicalRange(dict):
    '''
    PhysicalRange stores an interval of physical coordinates like ppm or s. It is used whenever we need to specify a part of spectra.
    '''
    def __init__(self, start:float, end:float, unit:str = "ppm",ref = 0.):
        super().__init__()
        self['start'] = start
        self['end'] = end
        self['unit'] = unit
        self['referenceFrequency'] = ref

    def getStart(self) -> float:
        return self['start']

    def getEnd(self) -> float:
        return self['end']

    def getUnit(self) -> str:
            return self['unit']

    def fromPhysicalRangeDTO(dto):
        return PhysicalRange(dto.start,dto.end)

#####################################################
#
#  Physical Range stored as a python dictionary
#
class IntegrationRegion(dict):
    def __init__(self, start, end, slope, bias):
        super().__init__()
        self['start'] = start
        self['end'] = end
        self['slope'] = slope
        self['bias'] = bias

    def fromIntegrationRegionDTO(dto: IntegrationRegionDto):
        return IntegrationRegion(start=dto.start, end=dto.end, slope=dto.slope, bias=dto.bias)


def convert_to_matrix(res):
    '''
    Convert a 2D data read as a linear array to a 2D matrix
    :param res: The data dictionary returned from NMRDataSet.getSpecDataPoints
    :return: the data dictionary with a new member 'dataMatrix'
    '''

    # the data points entry may be missing. This typical cause is a previous error
    if res.get(DATA_POINTS) is not None:
        data_points = res.pop(DATA_POINTS)

        # reshape it to the corresponding matrix
        six = int(res[INDEX_RANGES][0].getNum())
        siy = int(res[INDEX_RANGES][1].getNum())

        res[DATA_MATRIX] = numpy.reshape(data_points, (siy, six))

    return res

class NMRDataSet:
    '''
    NMRDataSet is an object representing one TopSpin data set. Such dataset consist of one experiment and one processing number:


    '''

    def __init__(self, top, identifier:str):
        '''
        :param top: TopSpin object
        :param identifier: Data set identifier. Usually the folder containing the processed data (1r ...)
        '''

        self._top = top
        self.api = self._top.apiClient
        self._path = identifier
        self._dataInfo = self.__fetchInfo()

        # get basic parameters
        pars = self.api.get_parameters(self.getIdentifier(), ["status OFFSET", "status SW_p", "status SFO1"])

        self.basicPars = {}
        for key, value in pars.items():
            self.basicPars[key] = float(value)
        #
        # cache left and right limit for ppm/index calculation
        #
        self._left_edge_0 = self.basicPars["status OFFSET"]
        self._right_edge_0 = self._left_edge_0 - self.getSW()

    # Fetch the data set info
    def __fetchInfo(self):
        return self.api.get_data_set_info(self.getIdentifier())

    # Get the data set identifier
    def getIdentifier(self) -> str:
        '''

        :return: the data set identifier
        '''
        return self._path

    # Get the dimension of the data set
    def getDimension(self) -> int:
        '''

        :return: the dimension of the acquired data set
        '''
        return self.getInfo()['raw_data_dimension']

    def getProcDim(self) -> int:
        '''
        The dimension of processed spectra may be lower than the dimension of acquired data (e.g. extracted 2D plane from a 3D data set)

        :return: dimension of the processed data
        '''
        return self.getInfo()['proc_data_dimension']

    def getInfo(self) -> NMRDataInfo:
        '''
        Get basic information about the data set in one call

        :return: a dictionary containing data set information
        '''
        return self._dataInfo

    def getTitle(self) -> str:
        '''
        Read the data set title

        :return: The content of the title file as a string
        '''
        try:
            return self.getProcFile('title')
        except:
            return None


    def getProcFile(self, filename: str) -> str:
        '''
         Get the content of a text file in the processed data folder

        :param filename: The name of a text file in the processed data folder
        :return: The content of a file as a string.
        '''
        return self.api.get_proc_file(data_set_path=self.getIdentifier(), file_name=filename)['content']

    def getRawFile(self, filename: str) -> str:
        '''
        Get the content of a text file in the raw data folder

        :param filename: The name of a text file in the processed data folder
        :return: The content of a file as a string.
        '''
        return self.api.get_raw_file(data_set_path=self.getIdentifier(), file_name=filename)['content']

    # Get a structure file from the data set
    def getStructureFile(self) -> str:
        '''
        Get a structure file (mol,sdf...) from the data set

        :return: content of the file
        '''
        return self.api.get_structure_file(data_set_path=self.getIdentifier())['content']

    def getPar(self, parName: str) -> str:
        '''
        Get the value of a parameter. The syntax used is the same as the respective commands used in the TopSpin command line.

        :param parName: name of the parameter

        :return: Parameter value as a string
        '''
        return self.api.get_parameters(self.getIdentifier(), [parName])[parName]



    def setPar(self, parName: str, parValue):
        '''
          Set the value of a parameter. The syntax used is the same as the respective commands used in the TopSpin command line.

          :param parName: name of the parameter
          :param parValue: value which should be set

        '''
        self.api.set_parameter(data_set_path=self.getIdentifier(), key=parName, value=str(parValue))


    def getParameters(self, parNames:[]):
        '''
         Get a set of parameters at once, return value is a dictionary

        :param parNames: a list of parameter names
        :return: a dictionary containing the parameter values. The parameter names are used as dictionary keys.
        '''
        return self.api.get_parameters(self.getIdentifier(), parNames)


    def __getProcSize(self, direction = 0):

        if direction == 0:
            return int(self.getPar("status SI"))

        if self.getProcDim() == 2 and direction == 1:
            return int(self.getPar("1s SI"))

        if self.getProcDim() == 3 and direction == 1:
            return int(self.getPar("2s SI"))

        if self.getProcDim() == 3 and direction == 2:
            return int(self.getPar("1s SI"))

        if self.getProcDim() == 4 and direction == 1:
            return int(self.getPar("3s SI"))

        if self.getProcDim() == 4 and direction == 2:
            return int(self.getPar("2s SI"))

        if self.getProcDim() == 4 and direction == 3:
            return int(self.getPar("1s SI"))

    def __getAcqSize(self, direction=0):

        if direction == 0:
            return int(self.getPar("status TD"))

        if self.getProcDim() == 2 and direction == 1:
            return int(self.getPar("1s TD"))

        if self.getProcDim() == 3 and direction == 1:
            return int(self.getPar("2s TD"))

        if self.getProcDim() == 3 and direction == 2:
            return int(self.getPar("1s TD"))

        if self.getProcDim() == 4 and direction == 1:
            return int(self.getPar("3s TD"))

        if self.getProcDim() == 4 and direction == 2:
            return int(self.getPar("2s TD"))

        if self.getProcDim() == 4 and direction == 3:
            return int(self.getPar("1s TD"))

    def getDataVector(self, component, indexRanges:[], dtype=numpy.float64):
        try:

            if not indexRanges:
                # we request explicit full size to avoid caching issus in TopSpin service
                indexRanges = []

                if component == RAWDATA:
                    for i in range(self.getDimension()):
                        indexRanges.append(IndexRange(0,self.__getAcqSize(i)))
                else:
                    for i in range(self.getProcDim()):
                        indexRanges.append(IndexRange(0,self.__getProcSize(i)))

            ir = []
            for i in indexRanges:
                ir.append(i.toIndexRangeDTO())
            index_ranges = IndexRangesDto(indexRanges=ir)

            res = self.api.get_data_set_with_index_ranges(self.getIdentifier(), component, index_ranges)

            # convert the data model to the JSON (input/output use the same format)
            ir = []
            for dto in res['index_ranges']:
                ir.append(IndexRange.fromIndexRangeDTO(dto))

            pr = []
            for dto in res['physical_ranges']:
                pr.append(PhysicalRange.fromPhysicalRangeDTO(dto))

            data_vector = {INDEX_RANGES: ir, PHYSICAL_RANGES: pr, DATA_POINTS: numpy.asarray(res['data_points'], dtype)}

            if res['x_values']:
                data_vector['x_values'] = numpy.asarray(res['x_values'], dtype)

            return data_vector
        except ApiException as ex:
            return {'exc':ex}

    def getSW(self) -> float:
        '''
        Get the spectrum width of the acquisition direction in **ppm** unit.

        :return: the spectrum width as a double value
        '''
        return self.basicPars["status SW_p"] / self.basicPars["status SFO1"]

    def getPhysicalFromIndex(self, index: float, direction: int = 0) -> float:
        '''
        Convert index in the processed data set vector (1r,2rr ..) to the physical coordinate (ppm)
        :param index:
        :param direction:
        :return:
        '''

        if direction == 0:
            return  self._left_edge_0 + index/self.__getProcSize(direction)* (self._right_edge_0 - self._left_edge_0)

        return None

    def getIndexFromPhysical(self,physical: float, direction:int = 0) -> int:

        '''
        Convert the physical coordinates (**ppm**) to a corresponding index in the processed data array

        :param physical: the ppm value to be converted
        :param direction: does apply only for nD data sets. Use 0 for the horizontal axis (acquistion direction), 1 for the vertical
        :return:
        '''

        if isinstance(physical,str):
            physical = float(physical)
        #
        # temporary implementation for 1D procdata
        #
        if direction == 0:
            res = int((physical - self._left_edge_0) / (self._right_edge_0 - self._left_edge_0) * (self.__getProcSize(direction)) + 0.5)

            return min(res, self.__getProcSize(direction) - 1)

        elif direction == 1:
            # read all required parameters in one shot
            basicPars = self.api.get_parameters(self.getIdentifier(), ["1s OFFSET", "1s SW_p", "1s SF", "1s AXLEFT", "1s AXRIGHT", "1s AXUNIT"])

            axleft = float(basicPars["1s AXLEFT"])
            axright = float(basicPars["1s AXRIGHT"])

            if axleft != axright:
                left = axleft
                right = axright
            else:
                left = float(basicPars["1s OFFSET"])
                right = left - float(basicPars["1s SW_p"]) / float(basicPars["1s SF"])

            res = int((physical - left) / (right - left) * (self.__getProcSize(direction)) + 0.5)

            return min(res, self.__getProcSize(direction) - 1)

    def getSpecDataPoints(self, component = PROCDATA, row:int = -1, column:int = -1, physRange = None,
                          ir = None, dtype=numpy.float64):
        '''
        Get processed data as an array of data points.

        :param component: specify part of spectrum to be read: use PROCDATA for real part (this is the default value)
            or PROCDATA_IMAG for imaginary part
        :param row: optional index of a row (applicable only for 2D data)
        :param column: optional index of a column (applicable only for 2D data)
        :param physRange:
        :param ir:
        :param precision:
        :return:
        '''

        if physRange is not None:
            #
            # create index range
            #
            ir = []
            idx = 0
            for ph in physRange:
                start = self.getIndexFromPhysical(ph['start'],idx)
                end = self.getIndexFromPhysical(ph['end'],idx)
                ir.append(IndexRange(min(start,end),abs(end - start)))
                idx = idx + 1

        if ir is None:
            if row >= 0:
                ir = [IndexRange(0, self.__getProcSize(0)), IndexRange(row, 1)]
            elif column >= 0:
                ir = [IndexRange(column, 1), IndexRange(0, self.__getProcSize(1))]

        return self.getDataVector(component,ir,dtype)

    def getSpecDataMatrix(self, component=PROCDATA, physRange=None, ir=None):
        '''
        Read the 2D dataset and return the result as corresponding 2D matrix

        :param component:
        :param physRange:
        :param ir:
        :return:
        '''

        # first, read the data set as a 1D array
        res = self.getSpecDataPoints(component=component, ir=ir, physRange=physRange)
        # convert it  to a 2D matrix
        return convert_to_matrix(res)

    def read_plane(self,direction, index):
        '''
                Read the 3D processed dataset and return the required plane as a 2D matrix

                :param direction: integer number specifying the plane requested.
                <br>Possible values for a 3D are: '12,13 and 23.
                :param index:
                :return:
        '''
        si3 = int(self.getPar("3s SI"))
        si2 = int(self.getPar("2s SI"))
        si1 = int(self.getPar("1s SI"))

        if direction == 32 or direction == 23:
            res = self.getSpecDataPoints(ir=[IndexRange(0, si3), IndexRange(0, si2), IndexRange(index, 1)])
            if res.get(EXCEPTION):
                print('Error :', res.get(EXCEPTION).details())
                exit(-1)

            dataPoints = res.pop(DATA_POINTS)
            res[DATA_MATRIX] = dataPoints.reshape(si2, si3)
            res[PHYSICAL_RANGES] = [res[PHYSICAL_RANGES][0],res[PHYSICAL_RANGES][1]]

            if direction == 32:
                res[DATA_MATRIX] = res[DATA_MATRIX].transpose()
                res[PHYSICAL_RANGES].reverse()
            return res

        if direction == 12 or direction == 21:
            res = self.getSpecDataPoints(ir=[IndexRange(index, 1), IndexRange(0, si2), IndexRange(0, si1)])
            if res.get(EXCEPTION):
                print('Error :', res.get(EXCEPTION).details())
                exit(-1)

            dataPoints = res.pop(DATA_POINTS)
            res[DATA_MATRIX] = dataPoints.reshape(si1, si2)
            res[PHYSICAL_RANGES] = [res[PHYSICAL_RANGES][2], res[PHYSICAL_RANGES][1]]

            if direction == 21:
                res[DATA_MATRIX] = res[DATA_MATRIX].transpose()
                res[PHYSICAL_RANGES].reverse()
            return res

        if direction == 13 or direction == 31:
            res = self.getSpecDataPoints(ir=[IndexRange(0, si3), IndexRange(index, 1), IndexRange(0, si1)])
            if res.get(EXCEPTION):
                print('Error :', res.get(EXCEPTION).details())
                exit(-1)

            dataPoints = res.pop(DATA_POINTS)
            res[DATA_MATRIX] = dataPoints.reshape(si1, si3)
            res[PHYSICAL_RANGES] = [res[PHYSICAL_RANGES][2], res[PHYSICAL_RANGES][0]]
            if direction == 31:
                # transpose also the axis!!
                res[DATA_MATRIX] = res[DATA_MATRIX].transpose()
                res[PHYSICAL_RANGES].reverse()
            return res

        return None

    #   Get vector of RAW data points (FID/SER file)
    def getRawDataPoints(self, row:int=-1, ir=None, precision = 'd'):
        if row is not None and row >= 0:
            si = self.getPar("status TD")
            ir = [IndexRange(0, si), IndexRange(row, 1)]

        return self.getDataVector(RAWDATA, ir,precision)


    def getIntegrationRegions(self):
        '''
        Get the 1D integration regions or None, if the region file does not exist
        :return:
        '''
        try:
            integration_regions: IntegrationRegionsDto = self.api.get_integration_regions(data_set_path=self.getIdentifier())
            return [IntegrationRegion.fromIntegrationRegionDTO(dto=dto) for dto in integration_regions.integrationRegions]
        except ApiException as ex:
            # StausCode Unknown is returne even when the region file does not exits
            #if ex.code() == grpc.StatusCode.INVALID_ARGUMENT:
            return None
            #else:
            #   raise ex

    def getPeakList(self):
        '''
        Get the   peak list or None, if the peak file does not exist
        :return:
        '''
        return self.api.get_peak_list(data_set_path=self.getIdentifier())

    def launch(self, command:str, arg:[] = None, wait:bool = True):
        '''
         Execute a command on the data set, wait until finished by default

        :param command: The command which should be executed,  e.g. 'efp'
        :param arg: optional arguments
        :param wait: specify if the call should wait until the command finished
        :return:
        '''
        self.api.execute_command(command=command, data_set_path=self.getIdentifier(), args=arg, wait=wait)


    def setTitle(self, text = ''):
        '''
        Write the data set title

        '''
        self.setProcFile('title',text)

    def setProcFile(self, filename: str, text = ''):
        '''
         write the content of a text file in the processed data folder

        :param filename: The name of a text file in the processed data folder
        :text: The content of a file as a string.
        '''
        with open(os.path.join(self.getIdentifier(),filename), 'w') as f:
            f.write(text)


    def setRawFile(self, filename: str, text =''):
        '''
         write the content of a text file in the acquired data folder

        :param filename: The name of a text file in the acquired data folder
        :text: The content of a file as a string.
        '''

        with open(os.path.join(os.path.dirname(os.path.dirname(self.getIdentifier())),filename), 'w') as f:
            f.write(text)

