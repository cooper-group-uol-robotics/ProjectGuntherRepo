from datetime import datetime
from enum import Enum
from typing import TypedDict, List

import grpc
from remote_api.dataset_pb2 import IndexRangeDto, PhysicalRangeDto


class NMRDataNucleiInfo(TypedDict):
    direction1: str
    direction2: str


class NMRDataInfo(TypedDict):
    dataset_path: str
    raw_data_dimension: int
    proc_data_dimension: int
    acquisition_date: datetime
    acquisition_nuclei: NMRDataNucleiInfo
    spectrometer_frequency: float
    solvent: str
    pulse_program: str
    spec_typ: str
    title: str


class NMRData(TypedDict):
    dataset_path: str
    component: str
    data_points: List[float]
    index_ranges: List[IndexRangeDto]
    physical_ranges: List[PhysicalRangeDto]
    x_values: List[float]


class PeakType(Enum):
    UNKNOWN = 0
    AUTOMATIC = 1
    MANUAL = 2
    IMPORTED = 3
    DECONVOLUTION = 4
    PROJECTED = 5
    SOLVENT = 6
    IMPURITY = 7
    NOISE = 8


class Peak(TypedDict):
    position: List[float]
    intensity: float
    type: PeakType
    annotation: str


class DataSetFile(TypedDict):
    name: str
    path: str
    content: str


class ApiException(Exception):
    def __init__(self, ex: grpc.RpcError):
        self.rpcError = ex

    def code(self) -> grpc.StatusCode:
        return self.rpcError.code()

    def details(self) -> str:
        return self.rpcError.details()
